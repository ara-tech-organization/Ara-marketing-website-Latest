import { CheckCircle, Users, Award, Clock } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

const AboutSection = () => {
  const achievements = [
    {
      icon: Users,
      number: "150+",
      title: "Happy Clients",
      description: "Businesses trust us with their digital transformation"
    },
    {
      icon: Award,
      number: "500+",
      title: "Projects Delivered", 
      description: "Successfully completed projects across various industries"
    },
    {
      icon: Clock,
      number: "5+",
      title: "Years Experience",
      description: "Proven expertise in digital solutions and marketing"
    }
  ];

  const values = [
    "Innovation-driven approach to every project",
    "Results-focused strategies that deliver ROI", 
    "Transparent communication throughout the process",
    "Cutting-edge technologies and best practices"
  ];

  return (
    <section className="py-24 bg-white relative overflow-hidden">
      {/* Decorative Elements */}
      <div className="absolute top-1/4 right-0 w-64 h-64 bg-gradient-primary opacity-5 rounded-full blur-3xl"></div>
      <div className="absolute bottom-1/4 left-0 w-48 h-48 bg-brand-teal/10 rounded-full blur-3xl"></div>

      <div className="relative container mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Content Side */}
          <div className="order-2 lg:order-1">
            <div className="inline-flex items-center space-x-2 bg-neutral-100 border border-border rounded-full px-4 py-2 mb-6">
              <div className="w-2 h-2 bg-brand-teal rounded-full animate-pulse"></div>
              <span className="text-sm font-secondary font-medium text-brand-teal">
                About DigitalCraft
              </span>
            </div>

            <h2 className="text-4xl md:text-5xl font-bold font-primary mb-6 leading-tight">
              <span className="text-foreground">Crafting Digital</span>
              <br />
              <span className="bg-gradient-accent bg-clip-text text-transparent">Excellence</span>
            </h2>

            <p className="text-lg text-neutral-600 font-secondary mb-8 leading-relaxed">
              We're a passionate team of digital innovators, designers, and strategists 
              dedicated to transforming businesses through powerful digital solutions. 
              Our mission is to bridge the gap between your vision and digital reality.
            </p>

            {/* Values List */}
            <div className="space-y-4 mb-10">
              {values.map((value, index) => (
                <div key={index} className="flex items-start space-x-3 group">
                  <CheckCircle className="w-6 h-6 text-brand-teal mt-0.5 group-hover:scale-110 transition-transform duration-300" />
                  <span className="text-neutral-700 font-secondary leading-relaxed">
                    {value}
                  </span>
                </div>
              ))}
            </div>

            <Link to="/about">
              <Button 
                variant="outline"
                size="lg"
                className="border-2 border-brand-teal text-brand-teal hover:bg-brand-teal hover:text-white font-secondary font-semibold px-8 py-4 rounded-xl transition-all duration-300 hover:scale-105 hover:shadow-glow"
              >
                Learn More About Us
              </Button>
            </Link>
          </div>

          {/* Visual Side */}
          <div className="order-1 lg:order-2">
            {/* Achievement Cards */}
            <div className="grid grid-cols-1 gap-6">
              {achievements.map((achievement, index) => {
                const Icon = achievement.icon;
                
                return (
                  <div
                    key={index}
                    className="bg-gradient-to-r from-white to-neutral-50 rounded-2xl p-6 shadow-soft hover:shadow-medium transition-all duration-300 hover:-translate-y-1 border border-neutral-100 group"
                  >
                    <div className="flex items-center space-x-4">
                      <div className="w-16 h-16 bg-gradient-primary rounded-xl flex items-center justify-center shadow-glow group-hover:scale-110 transition-transform duration-300">
                        <Icon className="w-8 h-8 text-white" />
                      </div>
                      
                      <div className="flex-1">
                        <div className="text-3xl font-bold font-primary text-brand-primary mb-1">
                          {achievement.number}
                        </div>
                        <h3 className="text-lg font-semibold font-primary text-foreground mb-1">
                          {achievement.title}
                        </h3>
                        <p className="text-sm text-neutral-600 font-secondary">
                          {achievement.description}
                        </p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Decorative Blob */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 -z-10">
              <div className="w-80 h-80 bg-gradient-cool opacity-10 rounded-full blur-3xl animate-pulse"></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
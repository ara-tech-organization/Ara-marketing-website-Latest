import { ArrowRight, Rocket, Zap, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

const CTASection = () => {
  const benefits = [
    {
      icon: Rocket,
      title: "Fast Launch", 
      description: "Get your project started within 48 hours"
    },
    {
      icon: Zap,
      title: "Quick Results",
      description: "See measurable improvements in 30 days"
    },
    {
      icon: Shield,
      title: "Risk-Free",
      description: "30-day money-back guarantee"
    }
  ];

  return (
    <section className="py-24 relative overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-brand-primary via-brand-primary-dark to-brand-primary">
        {/* Floating Elements */}
        <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-white/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-48 h-48 bg-brand-teal/20 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-white/5 rounded-full blur-3xl animate-pulse delay-500"></div>
      </div>

      {/* Geometric Decorations */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-10 w-20 h-20 border-2 border-white/20 rounded-xl rotate-45 animate-pulse"></div>
        <div className="absolute bottom-20 right-10 w-16 h-16 border-2 border-brand-teal/30 rounded-full animate-pulse delay-700"></div>
        <div className="absolute top-1/2 right-20 w-12 h-12 bg-white/10 rounded-full animate-pulse delay-300"></div>
      </div>

      <div className="relative container mx-auto px-6 text-center">
        {/* Main Content */}
        <div className="max-w-4xl mx-auto mb-16">
          <h2 className="text-5xl md:text-6xl lg:text-7xl font-bold font-primary text-white mb-8 leading-tight">
            Ready to Transform
            <br />
            <span className="bg-gradient-to-r from-white to-brand-teal bg-clip-text text-transparent">
              Your Business?
            </span>
          </h2>
          
          <p className="text-xl md:text-2xl text-white/90 font-secondary mb-12 leading-relaxed max-w-3xl mx-auto">
            Join hundreds of successful businesses that have accelerated their growth 
            with our proven digital solutions. Let's create something extraordinary together.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-6 mb-16">
            <Link to="/contact">
              <Button 
                size="lg"
                className="bg-white text-brand-primary hover:bg-neutral-100 font-secondary font-bold px-10 py-5 rounded-xl shadow-large hover:shadow-glow transition-all duration-300 hover:scale-105 group"
              >
                Start Your Project Now
                <ArrowRight className="ml-2 w-6 h-6 group-hover:translate-x-1 transition-transform" />
              </Button>
            </Link>
            
            <Link to="/services">
              <Button 
                variant="outline"
                size="lg"
                className="border-2 border-white text-white hover:bg-white hover:text-brand-primary bg-transparent font-secondary font-semibold px-10 py-5 rounded-xl hover:shadow-glow transition-all duration-300 group"
              >
                Explore Services
              </Button>
            </Link>
          </div>
        </div>

        {/* Benefits */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
          {benefits.map((benefit, index) => {
            const Icon = benefit.icon;
            
            return (
              <div
                key={index}
                className="flex flex-col items-center text-center group"
              >
                <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300 shadow-glow">
                  <Icon className="w-8 h-8 text-white" />
                </div>
                
                <h3 className="text-xl font-bold font-primary text-white mb-2">
                  {benefit.title}
                </h3>
                
                <p className="text-white/80 font-secondary">
                  {benefit.description}
                </p>
              </div>
            );
          })}
        </div>

        {/* Trust Indicators */}
        <div className="mt-20 pt-16 border-t border-white/20">
          <p className="text-white/80 font-secondary mb-6 text-lg">
            Trusted by industry leaders worldwide
          </p>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 max-w-2xl mx-auto">
            {[
              "Fortune 500 Companies",
              "Tech Startups", 
              "E-commerce Brands",
              "Service Providers"
            ].map((client, index) => (
              <div
                key={index}
                className="text-white/60 font-secondary font-medium text-sm uppercase tracking-wide hover:text-white transition-colors duration-300"
              >
                {client}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default CTASection;
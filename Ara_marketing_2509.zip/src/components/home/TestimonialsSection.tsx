import { Star, Quote } from "lucide-react";

const TestimonialsSection = () => {
  const testimonials = [
    {
      name: "Sarah Johnson",
      position: "CEO, TechStart Inc.",
      image: "/placeholder.svg",
      content: "DigitalCraft transformed our online presence completely. Their team's expertise in web development and digital marketing helped us increase our revenue by 300% in just 6 months.",
      rating: 5,
      company: "TechStart Inc."
    },
    {
      name: "Michael Chen",
      position: "Marketing Director, GrowthCo",
      image: "/placeholder.svg", 
      content: "The Meta and Google Ads campaigns they created for us were incredible. We saw a 250% increase in qualified leads and our cost per acquisition dropped by 40%.",
      rating: 5,
      company: "GrowthCo"
    },
    {
      name: "Emily Rodriguez", 
      position: "Founder, Creative Studios",
      image: "/placeholder.svg",
      content: "Their graphic design and video editing services are top-notch. They perfectly captured our brand vision and delivered stunning visuals that our clients absolutely love.",
      rating: 5,
      company: "Creative Studios"
    }
  ];

  const stats = [
    { number: "98%", label: "Client Satisfaction", color: "brand-primary" },
    { number: "250%", label: "Average ROI Increase", color: "brand-teal" },
    { number: "45%", label: "Faster Project Delivery", color: "brand-orange" },
    { number: "24/7", label: "Support Available", color: "brand-pink" }
  ];

  return (
    <section className="py-24 bg-gradient-to-br from-neutral-50 to-white relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-0 left-0 w-full h-full" 
             style={{
               backgroundImage: `url("data:image/svg+xml,%3csvg width='40' height='40' xmlns='http://www.w3.org/2000/svg'%3e%3cdefs%3e%3cpattern id='dots' width='40' height='40' patternUnits='userSpaceOnUse'%3e%3ccircle cx='20' cy='20' r='2' fill='%23585de8'/%3e%3c/pattern%3e%3c/defs%3e%3crect width='100%25' height='100%25' fill='url(%23dots)' /%3e%3c/svg%3e")`,
             }}>
        </div>
      </div>

      <div className="relative container mx-auto px-6">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center space-x-2 bg-white border border-border rounded-full px-4 py-2 mb-6 shadow-soft">
            <Star className="w-4 h-4 text-brand-orange fill-current" />
            <span className="text-sm font-secondary font-medium text-brand-orange">
              Client Success Stories
            </span>
          </div>
          
          <h2 className="text-4xl md:text-5xl font-bold font-primary mb-6">
            <span className="text-foreground">What Our Clients</span>
            <br />
            <span className="bg-gradient-warm bg-clip-text text-transparent">Say About Us</span>
          </h2>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 mb-20">
          {stats.map((stat, index) => (
            <div key={index} className="text-center group">
              <div className={`text-4xl md:text-5xl font-bold font-primary text-${stat.color} mb-2 group-hover:scale-110 transition-transform duration-300`}>
                {stat.number}
              </div>
              <div className="text-sm font-secondary text-neutral-600 uppercase tracking-wide">
                {stat.label}
              </div>
            </div>
          ))}
        </div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="bg-white rounded-2xl p-8 shadow-soft hover:shadow-large transition-all duration-500 hover:-translate-y-2 group relative border border-transparent hover:border-neutral-200"
            >
              {/* Quote Icon */}
              <div className="absolute -top-4 left-8">
                <div className="w-8 h-8 bg-gradient-primary rounded-full flex items-center justify-center shadow-glow">
                  <Quote className="w-4 h-4 text-white" />
                </div>
              </div>

              {/* Rating */}
              <div className="flex space-x-1 mb-6 mt-4">
                {[...Array(testimonial.rating)].map((_, starIndex) => (
                  <Star key={starIndex} className="w-5 h-5 text-brand-orange fill-current" />
                ))}
              </div>

              {/* Content */}
              <p className="text-neutral-700 font-secondary leading-relaxed mb-8">
                "{testimonial.content}"
              </p>

              {/* Author */}
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-gradient-primary rounded-full flex items-center justify-center shadow-glow">
                  <span className="text-white font-bold font-primary text-lg">
                    {testimonial.name.charAt(0)}
                  </span>
                </div>
                
                <div>
                  <h4 className="text-lg font-semibold font-primary text-foreground">
                    {testimonial.name}
                  </h4>
                  <p className="text-sm text-neutral-600 font-secondary">
                    {testimonial.position}
                  </p>
                  <p className="text-xs text-brand-primary font-secondary font-medium">
                    {testimonial.company}
                  </p>
                </div>
              </div>

              {/* Hover Effect */}
              <div className="absolute inset-0 bg-gradient-primary opacity-0 group-hover:opacity-5 rounded-2xl transition-opacity duration-300"></div>
            </div>
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="text-center mt-16">
          <p className="text-lg text-neutral-600 font-secondary mb-4">
            Join 150+ satisfied clients who've transformed their business with us
          </p>
          <div className="flex items-center justify-center space-x-2">
            {[...Array(5)].map((_, index) => (
              <Star key={index} className="w-6 h-6 text-brand-orange fill-current" />
            ))}
            <span className="ml-2 text-lg font-semibold font-secondary text-foreground">
              4.9/5 Average Rating
            </span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
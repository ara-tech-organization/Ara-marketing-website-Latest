import Layout from "../components/layout/Layout";
import { 
  Target, 
  Eye, 
  Users, 
  Award, 
  Heart, 
  Lightbulb, 
  Shield, 
  Zap,
  Calendar,
  TrendingUp,
  CheckCircle
} from "lucide-react";
import aboutTeamImage from "@/assets/about-team.jpg";
import aboutMissionImage from "@/assets/about-mission.jpg";
import aboutHistoryImage from "@/assets/about-history.jpg";

const About = () => {
  const milestones = [
    { year: "2019", title: "Company Founded", desc: "Started with a vision to transform digital experiences" },
    { year: "2020", title: "First 50 Clients", desc: "Built trust with innovative solutions and exceptional service" },
    { year: "2021", title: "Team Expansion", desc: "Grew to 25+ talented professionals across multiple disciplines" },
    { year: "2022", title: "Industry Recognition", desc: "Awarded 'Best Digital Agency' by Tech Innovation Awards" },
    { year: "2023", title: "Global Reach", desc: "Expanded services to clients across 15+ countries" },
    { year: "2024", title: "500+ Projects", desc: "Celebrating 500 successful projects and growing stronger" }
  ];

  const teamMembers = [
    { name: "Sarah Johnson", role: "CEO & Founder", expertise: "Strategic Leadership", initials: "SJ" },
    { name: "Michael Chen", role: "CTO", expertise: "Technical Innovation", initials: "MC" },
    { name: "Emily Rodriguez", role: "Creative Director", expertise: "Design Excellence", initials: "ER" },
    { name: "David Kim", role: "Marketing Director", expertise: "Growth Strategies", initials: "DK" },
    { name: "Lisa Wang", role: "Operations Manager", expertise: "Process Optimization", initials: "LW" },
    { name: "James Miller", role: "Lead Developer", expertise: "Full-Stack Development", initials: "JM" }
  ];

  const values = [
    {
      icon: Lightbulb,
      title: "Innovation First",
      description: "We constantly push boundaries and embrace cutting-edge technologies to deliver exceptional results.",
      color: "brand-primary"
    },
    {
      icon: Heart,
      title: "Client-Centric",
      description: "Your success is our priority. We build lasting partnerships based on trust and mutual growth.",
      color: "brand-teal"
    },
    {
      icon: Shield,
      title: "Quality Assurance",
      description: "Every project undergoes rigorous testing and quality checks to ensure flawless execution.",
      color: "brand-orange"
    },
    {
      icon: Zap,
      title: "Rapid Delivery",
      description: "We combine speed with precision, delivering projects efficiently without compromising quality.",
      color: "brand-pink"
    }
  ];

  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative py-32 bg-gradient-to-br from-brand-primary via-brand-primary-dark to-brand-primary overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-white/10 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-1/4 right-1/4 w-64 h-64 bg-brand-teal/20 rounded-full blur-3xl animate-pulse delay-1000"></div>
        </div>
        
        <div className="relative container mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <h1 className="text-5xl md:text-7xl font-bold font-primary text-white mb-8 leading-tight">
                Crafting Digital
                <span className="block bg-gradient-to-r from-white to-brand-teal bg-clip-text text-transparent">
                  Excellence
                </span>
              </h1>
              <p className="text-xl text-white/90 font-secondary mb-8 leading-relaxed">
                We're not just another digital agency. We're your strategic partners in building 
                extraordinary digital experiences that drive real business growth and lasting success.
              </p>
              <div className="flex items-center space-x-8">
                <div className="text-center">
                  <div className="text-3xl font-bold text-white font-primary">5+</div>
                  <div className="text-white/80 font-secondary text-sm">Years</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-white font-primary">500+</div>
                  <div className="text-white/80 font-secondary text-sm">Projects</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-white font-primary">150+</div>
                  <div className="text-white/80 font-secondary text-sm">Clients</div>
                </div>
              </div>
            </div>
            
            <div className="relative">
              <div className="relative z-10 rounded-2xl overflow-hidden shadow-large">
                <img 
                  src={aboutTeamImage} 
                  alt="DigitalCraft team collaborating" 
                  className="w-full h-96 object-cover"
                />
              </div>
              <div className="absolute inset-0 bg-gradient-primary opacity-20 rounded-2xl blur-xl transform translate-x-4 translate-y-4"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Mission & Vision Section */}
      <section className="py-24 bg-white relative overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute top-0 right-0 w-96 h-96 bg-brand-primary/5 rounded-full blur-3xl"></div>
          <div className="absolute bottom-0 left-0 w-64 h-64 bg-brand-teal/5 rounded-full blur-3xl"></div>
        </div>

        <div className="relative container mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
            {/* Mission */}
            <div className="relative">
              <div className="absolute -top-8 -left-8 w-16 h-16 bg-gradient-primary rounded-2xl flex items-center justify-center shadow-glow rotate-12">
                <Target className="w-8 h-8 text-white" />
              </div>
              
              <div className="bg-gradient-subtle rounded-3xl p-10 shadow-soft border border-neutral-100">
                <h2 className="text-4xl font-bold font-primary mb-6 text-foreground">Our Mission</h2>
                <p className="text-lg text-neutral-600 font-secondary leading-relaxed mb-8">
                  To empower businesses of all sizes with innovative digital solutions that drive growth, 
                  enhance user experiences, and create lasting competitive advantages in the digital landscape.
                </p>
                
                <div className="space-y-4">
                  {[
                    "Deliver exceptional digital experiences",
                    "Foster long-term client partnerships",
                    "Drive measurable business results",
                    "Innovate with purpose and precision"
                  ].map((item, index) => (
                    <div key={index} className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-brand-primary" />
                      <span className="font-secondary text-neutral-700">{item}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Vision */}
            <div className="relative">
              <div className="absolute -top-8 -right-8 w-16 h-16 bg-gradient-accent rounded-2xl flex items-center justify-center shadow-glow -rotate-12">
                <Eye className="w-8 h-8 text-white" />
              </div>
              
              <div className="bg-gradient-to-br from-brand-teal/5 to-brand-primary/5 rounded-3xl p-10 shadow-soft border border-neutral-100">
                <h2 className="text-4xl font-bold font-primary mb-6 text-foreground">Our Vision</h2>
                <p className="text-lg text-neutral-600 font-secondary leading-relaxed mb-8">
                  To become the global leader in digital transformation, recognized for our innovation, 
                  integrity, and ability to turn complex challenges into simple, elegant solutions.
                </p>
                
                <div className="grid grid-cols-2 gap-4">
                  {[
                    { icon: TrendingUp, text: "Industry Leadership" },
                    { icon: Users, text: "Global Impact" },
                    { icon: Lightbulb, text: "Continuous Innovation" },
                    { icon: Award, text: "Excellence Standard" }
                  ].map((item, index) => {
                    const Icon = item.icon;
                    return (
                      <div key={index} className="flex items-center space-x-2 text-sm">
                        <Icon className="w-4 h-4 text-brand-teal" />
                        <span className="font-secondary text-neutral-700">{item.text}</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>

          <div className="text-center mt-20">
            <img 
              src={aboutMissionImage} 
              alt="Mission and Vision representation" 
              className="w-full max-w-4xl mx-auto rounded-3xl shadow-large"
            />
          </div>
        </div>
      </section>

      {/* Company History */}
      <section className="py-24 bg-gradient-to-br from-neutral-50 to-neutral-100 relative">
        <div className="container mx-auto px-6">
          <div className="text-center mb-20">
            <div className="inline-flex items-center space-x-2 bg-white border border-border rounded-full px-4 py-2 mb-6 shadow-soft">
              <Calendar className="w-4 h-4 text-brand-orange" />
              <span className="text-sm font-secondary font-medium text-brand-orange">Our Journey</span>
            </div>
            
            <h2 className="text-4xl md:text-5xl font-bold font-primary mb-6">
              <span className="text-foreground">From Startup to</span>
              <br />
              <span className="bg-gradient-warm bg-clip-text text-transparent">Industry Leader</span>
            </h2>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center mb-20">
            <div>
              <img 
                src={aboutHistoryImage} 
                alt="Company growth timeline" 
                className="w-full rounded-2xl shadow-large"
              />
            </div>
            
            <div className="space-y-8">
              {milestones.map((milestone, index) => (
                <div key={index} className="flex items-start space-x-6 group">
                  <div className="flex-shrink-0 w-16 h-16 bg-gradient-primary rounded-xl flex items-center justify-center shadow-glow group-hover:scale-110 transition-transform duration-300">
                    <span className="text-white font-bold font-primary">{milestone.year}</span>
                  </div>
                  
                  <div>
                    <h3 className="text-xl font-bold font-primary text-foreground mb-2 group-hover:text-brand-primary transition-colors duration-300">
                      {milestone.title}
                    </h3>
                    <p className="text-neutral-600 font-secondary leading-relaxed">
                      {milestone.desc}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-6">
          <div className="text-center mb-20">
            <h2 className="text-4xl md:text-5xl font-bold font-primary mb-6">
              <span className="text-foreground">Meet Our</span>
              <br />
              <span className="bg-gradient-accent bg-clip-text text-transparent">Expert Team</span>
            </h2>
            <p className="text-xl text-neutral-600 font-secondary max-w-3xl mx-auto">
              Talented professionals dedicated to bringing your digital vision to life
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {teamMembers.map((member, index) => (
              <div
                key={index}
                className="bg-gradient-subtle rounded-2xl p-8 text-center shadow-soft hover:shadow-large transition-all duration-500 hover:-translate-y-2 group border border-neutral-100"
              >
                <div className="w-20 h-20 bg-gradient-primary rounded-full flex items-center justify-center mx-auto mb-6 shadow-glow group-hover:scale-110 transition-transform duration-300">
                  <span className="text-white font-bold text-xl font-primary">
                    {member.initials}
                  </span>
                </div>
                
                <h3 className="text-2xl font-bold font-primary text-foreground mb-2 group-hover:text-brand-primary transition-colors duration-300">
                  {member.name}
                </h3>
                
                <p className="text-brand-teal font-secondary font-semibold mb-3">
                  {member.role}
                </p>
                
                <p className="text-neutral-600 font-secondary">
                  {member.expertise}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Values & Culture */}
      <section className="py-24 bg-gradient-to-br from-brand-primary via-brand-primary-dark to-brand-primary text-white relative overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute top-1/4 right-1/4 w-64 h-64 bg-white/10 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-1/4 left-1/4 w-48 h-48 bg-brand-teal/20 rounded-full blur-3xl animate-pulse delay-1000"></div>
        </div>

        <div className="relative container mx-auto px-6">
          <div className="text-center mb-20">
            <h2 className="text-4xl md:text-5xl font-bold font-primary mb-6 text-white">
              Our Core Values
            </h2>
            <p className="text-xl text-white/90 font-secondary max-w-3xl mx-auto">
              The principles that guide everything we do and drive our commitment to excellence
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => {
              const Icon = value.icon;
              
              return (
                <div
                  key={index}
                  className="text-center group"
                >
                  <div className="w-20 h-20 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-glow group-hover:scale-110 transition-transform duration-300">
                    <Icon className="w-10 h-10 text-white" />
                  </div>
                  
                  <h3 className="text-2xl font-bold font-primary mb-4 text-white">
                    {value.title}
                  </h3>
                  
                  <p className="text-white/80 font-secondary leading-relaxed">
                    {value.description}
                  </p>
                </div>
              );
            })}
          </div>

          <div className="text-center mt-20">
            <p className="text-2xl text-white/90 font-secondary mb-8 max-w-4xl mx-auto leading-relaxed">
              "At DigitalCraft, we don't just build digital solutions – we craft experiences 
              that inspire, engage, and transform businesses for the better."
            </p>
            <p className="text-brand-teal font-secondary font-semibold text-lg">
              - Sarah Johnson, CEO & Founder
            </p>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default About;
import Layout from "../components/layout/Layout";
import { 
  Mail, 
  Phone, 
  MapPin, 
  Clock, 
  Send, 
  MessageSquare, 
  Users, 
  CheckCircle,
  HelpCircle,
  Plus,
  Minus
} from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import contactOfficeImage from "@/assets/contact-office.jpg";

const Contact = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    company: "",
    service: "",
    message: ""
  });
  const [openFaq, setOpenFaq] = useState<number | null>(null);
  const { toast } = useToast();

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Here you would typically send the form data to your backend
    toast({
      title: "Message Sent!",
      description: "We'll get back to you within 24 hours.",
    });
    
    // Reset form
    setFormData({
      name: "",
      email: "",
      company: "",
      service: "",
      message: ""
    });
  };

  const contactInfo = [
    {
      icon: Mail,
      title: "Email Us",
      detail: "hello@digitalcraft.com",
      description: "Send us an email anytime!",
      color: "brand-primary"
    },
    {
      icon: Phone,
      title: "Call Us",
      detail: "+1 (555) 123-4567",
      description: "Mon-Fri from 8am to 6pm",
      color: "brand-teal"
    },
    {
      icon: MapPin,
      title: "Visit Us",
      detail: "123 Innovation Drive, New York, NY 10001",
      description: "Our office is open to visitors",
      color: "brand-orange"
    },
    {
      icon: Clock,
      title: "Business Hours",
      detail: "Mon - Fri: 8:00 AM - 6:00 PM",
      description: "Weekend support available",
      color: "brand-pink"
    }
  ];

  const faqs = [
    {
      question: "How long does a typical project take?",
      answer: "Project timelines vary depending on scope and complexity. Simple websites take 2-4 weeks, while complex web applications can take 2-3 months. We always provide detailed timelines during our initial consultation."
    },
    {
      question: "Do you work with small businesses?",
      answer: "Absolutely! We work with businesses of all sizes, from startups to Fortune 500 companies. We have flexible packages and solutions that can accommodate any budget and requirement."
    },
    {
      question: "What's included in your maintenance packages?",
      answer: "Our maintenance packages include regular updates, security monitoring, performance optimization, backup management, and technical support. We offer different tiers to match your specific needs."
    },
    {
      question: "Can you help with existing websites?",
      answer: "Yes, we can redesign, optimize, or migrate existing websites. We also offer audit services to identify areas for improvement and provide recommendations for better performance."
    },
    {
      question: "Do you provide training for our team?",
      answer: "We offer comprehensive training sessions for content management systems, digital marketing tools, and analytics platforms. Training can be conducted on-site or remotely based on your preference."
    }
  ];

  return (
    <Layout>
      {/* Hero Section */}
      <section className="py-32 bg-gradient-to-br from-brand-primary via-brand-primary-dark to-brand-primary text-white relative overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-white/10 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-1/4 right-1/4 w-64 h-64 bg-brand-teal/20 rounded-full blur-3xl animate-pulse delay-1000"></div>
        </div>

        <div className="relative container mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <h1 className="text-5xl md:text-7xl font-bold font-primary mb-8 leading-tight">
                Let's Start
                <span className="block bg-gradient-to-r from-white to-brand-teal bg-clip-text text-transparent">
                  Something Great
                </span>
              </h1>
              <p className="text-xl text-white/90 font-secondary mb-8 leading-relaxed">
                Ready to transform your digital presence? We're here to help you every step of the way. 
                Get in touch and let's discuss how we can bring your vision to life.
              </p>
              
              <div className="flex items-center space-x-6">
                <div className="flex items-center space-x-2">
                  <MessageSquare className="w-6 h-6 text-brand-teal" />
                  <span className="text-white/90 font-secondary">24/7 Support</span>
                </div>
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-6 h-6 text-brand-teal" />
                  <span className="text-white/90 font-secondary">Free Consultation</span>
                </div>
              </div>
            </div>
            
            <div className="relative">
              <img 
                src={contactOfficeImage} 
                alt="DigitalCraft office" 
                className="w-full h-96 object-cover rounded-2xl shadow-large"
              />
              <div className="absolute inset-0 bg-gradient-primary/20 rounded-2xl"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Form & Info */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-16">
            {/* Contact Form */}
            <div className="lg:col-span-2">
              <div className="bg-gradient-subtle rounded-2xl p-8 shadow-soft border border-neutral-100">
                <div className="mb-8">
                  <h2 className="text-4xl font-bold font-primary text-foreground mb-4">
                    Send us a Message
                  </h2>
                  <p className="text-lg text-neutral-600 font-secondary">
                    Fill out the form below and we'll get back to you within 24 hours.
                  </p>
                </div>

                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label htmlFor="name" className="block text-sm font-semibold text-foreground mb-2 font-secondary">
                        Full Name *
                      </label>
                      <Input
                        id="name"
                        name="name"
                        type="text"
                        required
                        value={formData.name}
                        onChange={handleInputChange}
                        placeholder="Your full name"
                        className="w-full px-4 py-3 border border-neutral-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-brand-primary focus:border-transparent font-secondary"
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="email" className="block text-sm font-semibold text-foreground mb-2 font-secondary">
                        Email Address *
                      </label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        required
                        value={formData.email}
                        onChange={handleInputChange}
                        placeholder="your.email@company.com"
                        className="w-full px-4 py-3 border border-neutral-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-brand-primary focus:border-transparent font-secondary"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label htmlFor="company" className="block text-sm font-semibold text-foreground mb-2 font-secondary">
                        Company Name
                      </label>
                      <Input
                        id="company"
                        name="company"
                        type="text"
                        value={formData.company}
                        onChange={handleInputChange}
                        placeholder="Your company name"
                        className="w-full px-4 py-3 border border-neutral-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-brand-primary focus:border-transparent font-secondary"
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="service" className="block text-sm font-semibold text-foreground mb-2 font-secondary">
                        Service Interest
                      </label>
                      <select
                        id="service"
                        name="service"
                        value={formData.service}
                        onChange={handleInputChange}
                        className="w-full px-4 py-3 border border-neutral-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-brand-primary focus:border-transparent font-secondary bg-white"
                      >
                        <option value="">Select a service</option>
                        <option value="website-development">Website Development</option>
                        <option value="social-media-marketing">Social Media Marketing</option>
                        <option value="meta-ads">Meta Ads</option>
                        <option value="google-ads">Google Ads</option>
                        <option value="graphic-design">Graphic Design</option>
                        <option value="video-editing">Video Editing</option>
                        <option value="consultation">Free Consultation</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label htmlFor="message" className="block text-sm font-semibold text-foreground mb-2 font-secondary">
                      Message *
                    </label>
                    <Textarea
                      id="message"
                      name="message"
                      required
                      rows={6}
                      value={formData.message}
                      onChange={handleInputChange}
                      placeholder="Tell us about your project, goals, and how we can help you..."
                      className="w-full px-4 py-3 border border-neutral-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-brand-primary focus:border-transparent font-secondary resize-none"
                    />
                  </div>

                  <Button
                    type="submit"
                    size="lg"
                    className="w-full bg-gradient-primary hover:bg-gradient-accent text-white font-secondary font-semibold py-4 rounded-xl shadow-glow hover:shadow-large transition-all duration-300 hover:scale-[1.02] group"
                  >
                    Send Message
                    <Send className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </form>
              </div>
            </div>

            {/* Contact Information */}
            <div className="space-y-6">
              <div className="mb-8">
                <h3 className="text-2xl font-bold font-primary text-foreground mb-4">
                  Get in Touch
                </h3>
                <p className="text-neutral-600 font-secondary">
                  We're here to help and answer any questions you might have.
                </p>
              </div>

              {contactInfo.map((info, index) => {
                const Icon = info.icon;
                
                return (
                  <div
                    key={index}
                    className="flex items-start space-x-4 p-6 bg-gradient-subtle rounded-xl border border-neutral-100 hover:shadow-soft transition-all duration-300 group"
                  >
                    <div className={`w-12 h-12 bg-gradient-primary rounded-xl flex items-center justify-center shadow-glow group-hover:scale-110 transition-transform duration-300`}>
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                    
                    <div>
                      <h4 className="text-lg font-bold font-primary text-foreground mb-1">
                        {info.title}
                      </h4>
                      <p className="text-brand-primary font-secondary font-semibold mb-1">
                        {info.detail}
                      </p>
                      <p className="text-sm text-neutral-600 font-secondary">
                        {info.description}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* Google Map */}
      <section className="py-24 bg-gradient-to-br from-neutral-50 to-white">
        <div className="container mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold font-primary text-foreground mb-4">
              Visit Our Office
            </h2>
            <p className="text-lg text-neutral-600 font-secondary max-w-2xl mx-auto">
              Located in the heart of New York City, our office is easily accessible and always open for meetings.
            </p>
          </div>

          <div className="relative rounded-2xl overflow-hidden shadow-large">
            {/* Placeholder for Google Maps - replace with actual Google Maps embed */}
            <div className="w-full h-96 bg-gradient-to-br from-neutral-200 to-neutral-300 flex items-center justify-center">
              <div className="text-center">
                <MapPin className="w-16 h-16 text-brand-primary mx-auto mb-4" />
                <p className="text-xl font-semibold font-primary text-neutral-700 mb-2">
                  Interactive Map Coming Soon
                </p>
                <p className="text-neutral-600 font-secondary">
                  123 Innovation Drive, New York, NY 10001
                </p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
            {[
              { title: "Public Transport", desc: "2 minutes walk from subway station" },
              { title: "Parking", desc: "Free parking available on-site" },
              { title: "Accessibility", desc: "Fully wheelchair accessible building" }
            ].map((item, index) => (
              <div key={index} className="text-center p-6 bg-white rounded-xl shadow-soft">
                <h4 className="text-lg font-bold font-primary text-foreground mb-2">{item.title}</h4>
                <p className="text-neutral-600 font-secondary">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Office Information */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-4xl font-bold font-primary text-foreground mb-6">
                Why Visit Our Office?
              </h2>
              
              <div className="space-y-6">
                {[
                  {
                    icon: Users,
                    title: "Meet the Team",
                    description: "Get to know the passionate professionals who will work on your project"
                  },
                  {
                    icon: MessageSquare,
                    title: "In-Person Consultation",
                    description: "Discuss your project face-to-face for better understanding and collaboration"
                  },
                  {
                    icon: CheckCircle,
                    title: "See Our Work",
                    description: "Experience our portfolio and previous projects in our interactive showcase room"
                  }
                ].map((benefit, index) => {
                  const Icon = benefit.icon;
                  
                  return (
                    <div key={index} className="flex items-start space-x-4 group">
                      <div className="w-12 h-12 bg-gradient-primary rounded-xl flex items-center justify-center shadow-glow group-hover:scale-110 transition-transform duration-300">
                        <Icon className="w-6 h-6 text-white" />
                      </div>
                      
                      <div>
                        <h3 className="text-xl font-bold font-primary text-foreground mb-2">
                          {benefit.title}
                        </h3>
                        <p className="text-neutral-600 font-secondary leading-relaxed">
                          {benefit.description}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="bg-gradient-subtle rounded-2xl p-8 border border-neutral-100">
              <h3 className="text-2xl font-bold font-primary text-foreground mb-6">
                Schedule a Visit
              </h3>
              
              <div className="space-y-4 mb-6">
                <div className="flex items-center justify-between py-3 border-b border-neutral-200">
                  <span className="font-secondary text-neutral-700">Free Consultation</span>
                  <span className="font-secondary font-semibold text-brand-primary">30 min</span>
                </div>
                <div className="flex items-center justify-between py-3 border-b border-neutral-200">
                  <span className="font-secondary text-neutral-700">Project Planning</span>
                  <span className="font-secondary font-semibold text-brand-primary">60 min</span>
                </div>
                <div className="flex items-center justify-between py-3">
                  <span className="font-secondary text-neutral-700">Portfolio Review</span>
                  <span className="font-secondary font-semibold text-brand-primary">45 min</span>
                </div>
              </div>

              <Button 
                size="lg"
                className="w-full bg-gradient-primary hover:bg-gradient-accent text-white font-secondary font-semibold py-4 rounded-xl shadow-glow hover:shadow-large transition-all duration-300"
              >
                Book Appointment
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-24 bg-gradient-to-br from-neutral-50 to-white">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <div className="inline-flex items-center space-x-2 bg-white border border-border rounded-full px-4 py-2 mb-6 shadow-soft">
              <HelpCircle className="w-4 h-4 text-brand-primary" />
              <span className="text-sm font-secondary font-medium text-brand-primary">
                Frequently Asked Questions
              </span>
            </div>
            
            <h2 className="text-4xl md:text-5xl font-bold font-primary mb-6 text-foreground">
              Got Questions? We've Got Answers
            </h2>
            <p className="text-xl text-neutral-600 font-secondary max-w-3xl mx-auto">
              Find answers to the most common questions about our services and process
            </p>
          </div>

          <div className="max-w-4xl mx-auto space-y-4">
            {faqs.map((faq, index) => {
              const isOpen = openFaq === index;
              
              return (
                <div key={index} className="bg-white border border-neutral-200 rounded-xl shadow-soft overflow-hidden">
                  <button
                    className="w-full flex items-center justify-between p-6 text-left hover:bg-neutral-50 transition-colors duration-300"
                    onClick={() => setOpenFaq(isOpen ? null : index)}
                  >
                    <h3 className="text-lg font-bold font-primary text-foreground pr-4">
                      {faq.question}
                    </h3>
                    {isOpen ? (
                      <Minus className="w-6 h-6 text-brand-primary flex-shrink-0" />
                    ) : (
                      <Plus className="w-6 h-6 text-neutral-400 flex-shrink-0" />
                    )}
                  </button>
                  
                  {isOpen && (
                    <div className="px-6 pb-6">
                      <p className="text-neutral-600 font-secondary leading-relaxed">
                        {faq.answer}
                      </p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          <div className="text-center mt-12">
            <p className="text-lg text-neutral-600 font-secondary mb-6">
              Still have questions? We're here to help!
            </p>
            <Button 
              size="lg"
              className="bg-gradient-primary hover:bg-gradient-accent text-white font-secondary font-semibold px-8 py-4 rounded-xl shadow-glow hover:shadow-large transition-all duration-300 hover:scale-105"
            >
              Contact Support
            </Button>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Contact;